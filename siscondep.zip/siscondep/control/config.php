<?php
$host  = "localhost"; //endereço do seu servidor MySQL
$database = "siscondep"; //o database que conterá sua tabela, muitas vezes seu próprio login
?>